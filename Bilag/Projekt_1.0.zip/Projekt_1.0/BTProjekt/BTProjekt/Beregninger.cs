﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLag;
using System.Threading;
using BTProjekt;
using DTO;

namespace Logik
{
    public class Beregninger : APublisher, ISubscriber
    {       
        DataHent datahent = new DataHent();
        DataGem datagem = new DataGem();
        DAQ daq = new DAQ();

        // GemmaalingtilDB
        private List<double> gemmeliste = new List<double>();
        // getrange
        DTO_BT dtograf;
        private List<DTO_BT> DTOrange = new List<DTO_BT>();
        private List<double> rangelist = new List<double>();
        // getlatest1000average
        private List<double> latest1000 = new List<double>();
        // Update
        List<ISubscriber> subscribers = new List<ISubscriber>();
        private List<double> samplelist = new List<double>();
        // Slope
        private double slope; // mmHg/V
        private double beregnetslope; // mmHg/V
        // setNulpunktstryk
        private double nulpunktstryk;
        // Beregnblodtryk
        List<DTO_BT> dtolist;
        int counter = 0;
        private int tid1;
        private int tid2;
        private int tid3;
        private int tid4;
        private int tid5;
        private int filterkoefficienter = 10;

        // BeregnSYS/DIA
        private List<double> SYSliste = new List<double>();
        private List<double> DIAliste = new List<double>();
        // BeregnPuls
        private List<double> pulsliste = new List<double>();
        private List<double> pulslistekort = new List<double>();
        private List<double> pulspunkter = new List<double>();
        private double pulscounter = 0;
        private List<double> pulsintervaller = new List<double>();
        private double interval;

        // Record
        private int startgem;
        private int slutgem;
        

        public Beregninger()
        {
            daq.AttachSubscriber(this);
            slope = datahent.getslopeasdouble();
            nulpunktstryk = datahent.getsnulpunktsdouble();
            dtolist = new List<DTO_BT>();
        }
      // __________________________  DATATRANSFER ____________________________ //


        // ------------------ Database metoder
        public bool gemmaalingtilDB(List<double> trykliste_, int startgem_, int slutgem_,int maaleid_, string ansvarlig_, string kommentar_, double slope_, double nulpunkt_,List<double> samplelist_)
        {

            gemmeliste.Clear();
            for (int i = startgem_; i < slutgem_; i++)
            {
                gemmeliste.Add(trykliste_[i] * slope_ - nulpunkt_);
            }            
            return datagem.gemmaalingtilDB(gemmeliste,maaleid_,ansvarlig_,kommentar_);  
                 
        }
        public int getmaaleid()
        {
            return datahent.getmaaleid();
        }

        // ------------------- Kalibrering
        public bool gemkalibrering(double slope_, string ansvarlig_)
        {
            slope = slope_;
            return datagem.gemkalibrering(slope, ansvarlig_);            
        }
        public string getslopestring()
        {
            return datahent.getslopestring();
        }
        public double getslopedouble()
        {
            return slope;
        }

        // -------------------- Nulpunktsjustering
        public bool setNulpunktstryk(double tryk)
        {
            try
            {
                nulpunktstryk = tryk;
                datagem.gemNulpunktsjustering(tryk);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public string getnulpunktsstring()
        {
            return datahent.getsnulpunktstring();
        }
        public double getnulpunktdouble()
        {
            return nulpunktstryk;
        }

        // -------------------- Andre metoder
        public List<double> getlatest1000()
        {
            try
            {
                latest1000 = samplelist.GetRange(samplelist.Count() - 1001, 1000);
                return latest1000;
            }
            catch (Exception)
            {
                return samplelist;
            }
        }

        public List<DTO_BT> getrange(int start_, int slut_, List<double> samplelist_, double slope_, double nulpunkt_)
        {
            rangelist.Clear();
            DTOrange.Clear();
            rangelist = samplelist_.GetRange(start_, slut_ - start_);
            for (int i = 0; i < rangelist.Count; i++)
            {
                DTOrange.Add(dtograf = new DTO_BT(i, rangelist[i]));
                dtograf.setvoltage(dtograf.getvoltage() * slope - nulpunktstryk);
            }
            return DTOrange;
        }
        public List<double> getsamplelist()
        {
            return samplelist;
        }
        //public void gemtilfil(List<double> samplelist, string kommentar_, string ansvarlig_)
        //{
        //    datagem.gemtilFil(samplelist, kommentar_,ansvarlig_);
        //}
        public int getStart()
        {
            return startgem;
        }
        public int getSlut()
        {
            return slutgem;
        }



        // _______________________  ALGORITME_________________________ //
        public void startreader(string inputport, double min, double max, double samplefrekvens, int antalsamples)
        {
            daq.startreader(inputport, min, max, samplefrekvens, antalsamples);
        }
        public double beregnKalibrering(double p1, double p2, double v1, double v2) // Beregner kalibreringskonstant
        {
            beregnetslope = (v2 - v1) / (p2 - p1);
            return 1/beregnetslope*1000;
        } 
        public double beregnSpænding() // til kalibrering
        {
            return samplelist.GetRange(samplelist.Count - 50, 50).Average()*1000;
        }
        public double Beregnpuls()  // Beregner puls 
        {
            pulscounter = 0;
            pulslistekort.Clear();
            pulsliste.Clear();
            try
            {
                pulsliste = samplelist.GetRange(samplelist.Count() - 10001, 10000);
                for (int i = 0; i < pulsliste.Count; i = i + 50)
                {
                    pulslistekort.Add(pulsliste[i]);
                }
                for (int i = 1; i < pulslistekort.Count - 1; i++)
                {
                    if (pulslistekort[i] > pulslistekort[i - 1] && pulslistekort[i] > pulslistekort[i + 1] && pulslistekort[i] > pulslistekort.Average() + 0.1)
                    {
                        pulscounter++;
                    }
                }

                return pulscounter * 6;
            }
            catch (Exception)
            {

                pulsliste = samplelist.GetRange(samplelist.Count() - 3001, 3000);
                for (int i = 0; i < pulsliste.Count; i = i + 50)
                {
                    pulslistekort.Add(pulsliste[i]);
                }
                pulsintervaller.Clear();
                for (int i = 1; i < pulslistekort.Count - 1; i++)
                {
                    if (pulslistekort[i] > pulslistekort[i - 1] && pulslistekort[i] > pulslistekort[i + 1] && pulslistekort[i] > pulslistekort.Average() + 0.1)
                    {
                        pulsintervaller.Add(i*50);
                    }
                }
                interval = 0;
                for (int i = 0; i < pulsintervaller.Count-1; i++)
                {
                    interval = interval + pulsintervaller[i + 1] - pulsintervaller[i];
                   
                }
                return 60 / (interval / 1000 / (pulsintervaller.Count() - 1));



            }
            
        }
        public List<DTO_BT> beregnblodtryk(List<double> liste, bool filterOn) // returnerer ÉEN dto fra liste af doubles
        {
            counter = counter + 50;
            dtolist.Clear();
            if (filterOn == false) 
            {
                tid1 = counter - 40;
                tid2 = tid1 + 10;
                tid3 = tid2 + 10;
                tid4 = tid3 + 10;
                tid5 = tid4 + 10;

                dtolist.Add(new DTO_BT(tid1,liste[9]*slope-nulpunktstryk));
                dtolist.Add(new DTO_BT(tid2, liste[19] * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid3, liste[29] * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid4, liste[39] * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid5, liste[49] * slope - nulpunktstryk));
                return dtolist;
            }
            else
            {
                tid1 = counter - 40;
                tid2 = tid1 + 10;
                tid3 = tid2 + 10;
                tid4 = tid3 + 10;
                tid5 = tid4 + 10;

                dtolist.Add(new DTO_BT(tid1, liste.GetRange(0, filterkoefficienter).Average() * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid2, liste.GetRange(10, filterkoefficienter).Average() * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid3, liste.GetRange(20, filterkoefficienter).Average() * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid4, liste.GetRange(30, filterkoefficienter).Average() * slope - nulpunktstryk));
                dtolist.Add(new DTO_BT(tid5, liste.GetRange(40, filterkoefficienter).Average() * slope - nulpunktstryk));
                return dtolist;
            }
            
        }
        public double BeregnSYS ()
        {
            SYSliste = samplelist.GetRange(samplelist.Count - 1001, 1000);
            return SYSliste.Max()*slope-nulpunktstryk;
        }
        public double BeregnDIA()
        {
            SYSliste = samplelist.GetRange(samplelist.Count - 1001, 1000);
            return SYSliste.Min() * slope - nulpunktstryk;
        }
        public void record(bool recording)
        {

            if (recording == false)
            {
                startgem = samplelist.Count();
            }
            else
            {
                slutgem = samplelist.Count();
            }

        }

        // __________________  PUBLISHER/SUBSCRIBER___________________ //
        public void AttachSubscriber(ISubscriber subscriber)
        {
            subscribers.Add(subscriber);
        }
        private void NotifySubscriber(List<double> blodtryk)
        {
            foreach (ISubscriber sub in subscribers)
            {
                sub.Update(blodtryk);
            }
        }
        public void Update(List<double> sampleudsnit)
        {
            NotifySubscriber(sampleudsnit);
            samplelist.AddRange(sampleudsnit);
        }

    }
}
