﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.ComponentModel;
using System.Drawing;
using NationalInstruments.DAQmx;
using NationalInstruments;
using System.Collections;
using DTO;
using System.Linq;
using BTProjekt;


namespace DataLag
{
    class DAQ : APublisher
    {
        private AnalogMultiChannelReader analogInReader;
        private Task myTask;
        private Task runningTask;
        private AsyncCallback analogCallback;

        

        private AnalogWaveform<double>[] data;

        private System.ComponentModel.Container components = null;

        //  EGET :)
        private List<ISubscriber> subscribers = new List<ISubscriber>();
        private int samplesPrChannel;
        private List<double> samplelist = new List<double>();
        int counter = 0;
        //

        public void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
                if (myTask != null)
                {
                    runningTask = null;
                    myTask.Dispose();
                }
            }           
        }
        public bool IsRunning()
        {
            if (runningTask != null)
            {
                return true;
            }
            else { return false; }
        }
        public void startreader(string inputport, double min, double max,double samplefrekvens, int antalsamples)
        {
            
            if (runningTask == null)
            {
                try
                {

                    samplesPrChannel = antalsamples;
                    
                    // Create a new task
                    myTask = new NationalInstruments.DAQmx.Task();

                    // Create a virtual channel
                    myTask.AIChannels.CreateVoltageChannel(inputport, "",
                        (AITerminalConfiguration)(-1), min,
                        max, AIVoltageUnits.Volts);

                    // Configure the timing parameters
                    myTask.Timing.ConfigureSampleClock("", samplefrekvens,
                        SampleClockActiveEdge.Rising, SampleQuantityMode.ContinuousSamples,antalsamples); // ændret fra 1000 til samplesPrChannel

                    // Verify the Task
                    myTask.Control(TaskAction.Verify);

                    runningTask = myTask;
                    analogInReader = new AnalogMultiChannelReader(myTask.Stream);
                    analogCallback = new AsyncCallback(AnalogInCallback);

                    // Use SynchronizeCallbacks to specify that the object 
                    // marshals callbacks across threads appropriately.
                    analogInReader.SynchronizeCallbacks = true;
                    analogInReader.BeginReadWaveform(antalsamples,
                        analogCallback, myTask);
            }
                catch (DaqException exception)
            {
                runningTask = null;
                myTask.Dispose();
            }
        }
        }
        private void AnalogInCallback(IAsyncResult ar)
        {
            try
            {
                if (runningTask != null && runningTask == ar.AsyncState)
                {
                    // Read the available data from the channels
                    data = analogInReader.EndReadWaveform(ar);

                    // Plot your data here
                    dataToDataTable(data);

                    analogInReader.BeginMemoryOptimizedReadWaveform(samplesPrChannel,
                        analogCallback, myTask,data);

                }
            }
            catch (DaqException exception)
            {
                // Display Errors
                runningTask = null;
                myTask.Dispose();
            }
        }
        private void stop(object sender, System.EventArgs e)
        {
            if (runningTask != null)
            {
                // Dispose of the task
                runningTask = null;
                myTask.Dispose();

            }
        }
        private void dataToDataTable(AnalogWaveform<double>[] sourceArray)
        {
            int currentLineIndex = 0;           
            foreach (AnalogWaveform<double> waveform in sourceArray)
            {
                for (int sample = 0; sample < waveform.Samples.Count; ++sample)
                {
                    samplelist.Add(waveform.Samples[sample].Value);                 
                }
                 NotifySubscriber(samplelist.GetRange(samplelist.Count - 50, 50));
                currentLineIndex++;
                counter++;
            }
        }
        public List<double> getsamples()
        {
            return samplelist;
        }

        public void AttachSubscriber(ISubscriber subscriber)
        {
            subscribers.Add(subscriber);
        }
        private void NotifySubscriber(List<double> blodtryk)
        {
            foreach (ISubscriber sub in subscribers)
            {
                sub.Update(blodtryk);
            }
        }

    }
}
