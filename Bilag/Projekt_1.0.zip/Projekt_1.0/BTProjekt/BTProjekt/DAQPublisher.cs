﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace BTProjekt
{
    abstract class DAQPublisher
    {
        private ISubscriber subscriber_;

        public void Attach(ISubscriber subscriber)
        {
            subscriber_ = subscriber;
        }

        public void Notify(List<double> sampleudsnit)
        {
            subscriber_.UpdateBeregninger(sampleudsnit);
        }
    }
}
