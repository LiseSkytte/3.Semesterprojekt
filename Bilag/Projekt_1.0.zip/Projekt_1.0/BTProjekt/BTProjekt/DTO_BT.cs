﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DTO
{
    public class DTO_BT
    {
        private double sek_;
        private double spænding_;
        

        public DTO_BT(int sample, double spænding)
        {
            sek_ = Convert.ToDouble(sample) / 1000;
            spænding_ = spænding;
        }
        

        public double gettime()
        {
            return sek_;
        }

        public double getvoltage()
        {
            return spænding_;
        }

        public void setvoltage(double newpressure)
        {
            spænding_ = newpressure;
        }

    }
}
