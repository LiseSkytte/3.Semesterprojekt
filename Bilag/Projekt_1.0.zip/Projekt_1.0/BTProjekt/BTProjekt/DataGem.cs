﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Data;
using System.Data.SqlClient;


namespace DataLag
{
    class DataGem
    {
        // gemtilFil
        private List<double> backupliste = new List<double>();
        private double[] samplearray;
        private int counter;
        string tidsstempel;
        int skrivfra = 0;
        private List<string> samplestrings;

        // gemmaalingtilDB
        SqlConnection conn;
        SqlCommand cmd;
        private const string db = "F15ST2ITS2201404118";    // Anders info til server
        private bool gemmeresultat;

        //public void gemtilFil(List<double> backupliste, string kommentar_, string ansvarlig_) // Gemmer måling til .txt fil.
        //{

        //    string gemmestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_BT_Signaler\" + kommentar_ + ".txt";
        //    samplestrings = new List<string>();
        //    samplestrings.Clear();
        //    for (int i = 0; i < backupliste.Count; i++)
        //    {
        //        samplestrings.Add(Convert.ToString(backupliste[i]));
        //    }

        //    for (int i = 0; i < samplestrings.Count; i++)
        //    {
        //        System.IO.File.AppendAllLines(gemmestring,samplestrings);
        //    }
        //    Console.WriteLine("data gemt");
        //}

        public bool gemmaalingtilDB(List<double> samplelist,int maaleid, string ansvarlig, string kommentar)
        {
            try
            {
                samplearray = samplelist.ToArray();

                conn = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + db + ";Persist Security Info=True;User ID=" + db + ";Password=" + db + "");
                //Linq - henter alle værdier ud én af gangne og konverterer dem til Bytes og smider dem til sidste ud i et array
                byte[] data = samplearray.SelectMany(value => BitConverter.GetBytes(value)).ToArray();
                conn.Open();            // Åbner forbindelse til SQL forbindelse som har navnet conn
                tidsstempel = Convert.ToString(DateTime.Now);

                // Insert into statement der indsætter array oprettet table
                cmd = new SqlCommand("Insert into BTmaaling (maaleid, maaling, tid, ansvarlig, kommentar) values (@maaleid,@maaling, @tidsstempel, @ansvarlig,@kommentar)", conn);
                cmd.Parameters.Add("@maaling", SqlDbType.VarBinary, data.Length).Value = data; // "Binder" @testarray med arrayafmaalinger
                cmd.Parameters.Add("@tidsstempel", SqlDbType.DateTime).Value = tidsstempel;
                cmd.Parameters.Add("@maaleid", SqlDbType.Int).Value = maaleid;
                cmd.Parameters.Add("@ansvarlig", SqlDbType.VarChar).Value = ansvarlig;
                cmd.Parameters.Add("@kommentar", SqlDbType.VarChar).Value = kommentar;



                cmd.ExecuteNonQuery();
                conn.Close();
                gemmeresultat = true;
            }
            catch (Exception)
            {
                gemmeresultat = false;
            }
            return gemmeresultat;    
        
        }      
        public bool gemkalibrering(double slope, string navn)
        {
            try
            {
                string gemmestringkalibrer = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Kalibreringer\" + "Kalibreringsdata" + ".txt";
                System.IO.File.AppendAllText(gemmestringkalibrer, "\r\nKalibrering foretaget: " + DateTime.Now + " Udført af: " + navn + " Værdi mmHg/V; " + slope);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        public void gemNulpunktsjustering(double Tryk) // Gemmer Tryk til .txt fil.
        {                      
            string gemmestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Nulpunktsjusteringer\Nulpunkter.txt";
            System.IO.File.AppendAllText(gemmestring, "Nulpunktsjusteret "+DateTime.Now+" Tryk (mmHg); "+Tryk+"\r\n");
        }
    }
    
}
