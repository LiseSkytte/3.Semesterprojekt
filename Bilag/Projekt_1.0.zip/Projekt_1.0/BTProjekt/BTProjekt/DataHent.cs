﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BTProjekt;
using System.Data;
using System.Threading;
using System.ComponentModel;
using System.Data.SqlClient;
using DTO;
using System.IO;



namespace DataLag
{

    class DataHent
    {


        // DATABASE INFO       
        SqlConnection conn;
        SqlCommand cmd;
        private const string db = "F15ST2ITS2201404118";                    // Anders info til server

        // getslopestring
        string doublestring;
        string[] slopestringarray;
        // getslopesdouble
        string[] slopearray;
        
        
        // getnulpunktstring
        string tryk;
        string[] trykstringarray;

        // getnulpunktdouble
        string trykdoublestring;
        string[] trykarray;

        // Slopestring
        string slopestring;

        private List<int> maaleidliste = new List<int>();
       
        public int getmaaleid() // Returnerer maaleid, som er det maaleid der er gemt i DB sidst.
        {
            try
            {
                conn = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + db + ";Persist Security Info=True;User ID=" + db + ";Password=" + db + "");
                conn.Open();            

                cmd = new SqlCommand("select maaleid FROM BTmaaling",conn);
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())               
            {
                maaleidliste.Add(Convert.ToInt16(rdr["maaleid"].ToString()));
            }

            conn.Close();
            return maaleidliste.Max();

            }

            catch (Exception)
            {
                return 0;
            }
            
        }

        public double getslopeasdouble()
        {
            try
            {
                string hentestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Kalibreringer\" + "Kalibreringsdata" + ".txt";
                doublestring = File.ReadLines(hentestring).Last();
                slopearray = doublestring.Split(';');

                return Convert.ToDouble(slopearray[1]);
            }
            catch (Exception)
            {
                return 60;
            }
        }

        public string getslopestring()
        {
            try
            {
                string hentestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Kalibreringer\" + "Kalibreringsdata" + ".txt";
                slopestringarray = File.ReadLines(hentestring).Last().Split(';');
            slopestring =  slopestringarray[0]+ " " + Convert.ToString(Math.Round(Convert.ToDouble(slopestringarray[1]),2));
                return slopestring;
        }
            catch (Exception)
            {
                return "kalibreringsdata kan ikke hentes, kontroller kalibreringsfil.";
            }
        }

        public double getsnulpunktsdouble()
        {
            try
            {
                string hentestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Nulpunktsjusteringer\Nulpunkter.txt";
                trykdoublestring = File.ReadLines(hentestring).Last();
                trykarray = trykdoublestring.Split(';');


                return Convert.ToDouble(trykarray[1]);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public string getsnulpunktstring()
        {
            try
            {
                string hentestring = @"C:\Users\Anders\Dropbox\Semesterprojekt 3 - Gruppe 1\Software\Gemte_Nulpunktsjusteringer\Nulpunkter.txt";
                trykstringarray = File.ReadLines(hentestring).Last().Split(';');
                tryk = trykstringarray[0] + " " + Convert.ToString(Math.Round(Convert.ToDouble(trykstringarray[1]),2));

                return tryk;
            }
            catch (Exception)
            {
                return "Fil ikke fundet";
            }
        }


    }
}
