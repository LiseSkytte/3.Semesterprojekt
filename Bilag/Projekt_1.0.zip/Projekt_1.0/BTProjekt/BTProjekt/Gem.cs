﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logik;
using DTO;

namespace GUI
{
    public partial class Gem : Form
    {
        Beregninger beregninger;
        private bool gemmeresultat = false;
        private int startgem;
        private int slutgem;
        private double slope;
        private double nulpunkt;
        private List<double> samplelist;
        // Visgemgraf
        List<DTO_BT> grafliste;
  
        public Gem(Beregninger beregn,double slope_, double nulpunkt_,int startgem_, int slutgem_, List<double> samplelist_)
        {
            InitializeComponent();
            textBoxKommentar.Text = "Kommentar";
            textBoxAnsvarlig.Text = "Ansvarlig";
            beregninger = beregn;
            slope = slope_;
            nulpunkt = nulpunkt_;
            startgem = startgem_;
            slutgem = slutgem_;
            samplelist = samplelist_;

            // GRAPH VISUALS
            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.ChartAreas[0].AxisY.Minimum = -100;
            chart1.ChartAreas[0].AxisY.Maximum = 180;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisY.Interval = 20;
        }

        void btnOK_Click(object sender, EventArgs e)
        { 

            if (gemmeresultat = beregninger.gemmaalingtilDB(samplelist, startgem, slutgem, beregninger.getmaaleid() + 1, textBoxAnsvarlig.Text, textBoxKommentar.Text, slope, nulpunkt, samplelist) == true)
            {
                textBoxKommentar.Text = "Måling er gemt. Målingens ID er: " + beregninger.getmaaleid() + "\r\nVindue kan lukkes";
                btnOK.Enabled = false;
                textBoxAnsvarlig.Enabled = false;
                textBoxKommentar.Enabled = false;
            }
            else
            {
                textBoxKommentar.Text = "Måling er ikke gemt. Kontroller VPN forbindelse";
                btnOK.Enabled = true;
                textBoxAnsvarlig.Enabled = true;
                textBoxKommentar.Enabled = true;
            }
           
        }


        public void visGemGraf()
        {
            try
            {
                chart1.Series[0].Points.Clear();
                grafliste = beregninger.getrange(startgem,slutgem,samplelist,slope,nulpunkt);
                for (int i = 0; i < grafliste.Count; i++)
                {
                    chart1.Series[0].Points.AddXY(grafliste[i].gettime(), grafliste[i].getvoltage());
                }
                chart1.ChartAreas[0].AxisX.Maximum = grafliste[grafliste.Count() - 1].gettime();
                chart1.ChartAreas[0].AxisX.Minimum = grafliste[0].gettime();
                chart1.ChartAreas[0].CursorX.AutoScroll = true;
                chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas[0].AxisY.Minimum = Math.Round( samplelist.Min()* slope-nulpunkt,0) - 10;
                chart1.ChartAreas[0].AxisY.Maximum = Math.Round( samplelist.Max() * slope-nulpunkt,0) + 10;

                int position = 0;
                int size = 4;
                chart1.ChartAreas[0].AxisX.ScaleView.Zoom(position, size);
                chart1.ChartAreas[0].AxisX.RoundAxisValues();
                chart1.Series[0].BorderWidth = 2;
                chart1.ChartAreas[0].AxisX.RoundAxisValues();
            }
            catch (Exception)
            {
                textBoxKommentar.Text = ("Graf kan ikke udskrives, prøv igen");
            }
            
        }

    }
}
