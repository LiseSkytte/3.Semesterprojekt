﻿namespace GUI
{
    partial class Kalibrer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtResultat = new System.Windows.Forms.TextBox();
            this.btnBeregn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtAnsvarlig = new System.Windows.Forms.TextBox();
            this.numP1 = new System.Windows.Forms.NumericUpDown();
            this.numV1 = new System.Windows.Forms.NumericUpDown();
            this.numP2 = new System.Windows.Forms.NumericUpDown();
            this.numV2 = new System.Windows.Forms.NumericUpDown();
            this.btnMål1 = new System.Windows.Forms.Button();
            this.btnMål2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numV1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numV2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnOK.Enabled = false;
            this.btnOK.Font = new System.Drawing.Font("Arial", 21.86387F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnOK.Location = new System.Drawing.Point(428, 478);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(279, 163);
            this.btnOK.TabIndex = 21;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Location = new System.Drawing.Point(46, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 29);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tryk 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(248, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 29);
            this.label1.TabIndex = 25;
            this.label1.Text = "Spænding 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.93194F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(124, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 36);
            this.label2.TabIndex = 26;
            this.label2.Text = "Indtast Værdier";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Location = new System.Drawing.Point(152, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 29);
            this.label4.TabIndex = 27;
            this.label4.Text = "mmHg";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.Location = new System.Drawing.Point(370, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 29);
            this.label5.TabIndex = 28;
            this.label5.Text = "mV";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.Location = new System.Drawing.Point(370, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 29);
            this.label6.TabIndex = 34;
            this.label6.Text = "mV";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.Location = new System.Drawing.Point(152, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 29);
            this.label7.TabIndex = 33;
            this.label7.Text = "mmHg";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.Location = new System.Drawing.Point(248, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 29);
            this.label8.TabIndex = 32;
            this.label8.Text = "Spænding 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.Location = new System.Drawing.Point(46, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 29);
            this.label9.TabIndex = 31;
            this.label9.Text = "Tryk 2";
            // 
            // txtResultat
            // 
            this.txtResultat.Location = new System.Drawing.Point(428, 336);
            this.txtResultat.Multiline = true;
            this.txtResultat.Name = "txtResultat";
            this.txtResultat.Size = new System.Drawing.Size(315, 125);
            this.txtResultat.TabIndex = 41;
            // 
            // btnBeregn
            // 
            this.btnBeregn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBeregn.Font = new System.Drawing.Font("Arial", 21.86387F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBeregn.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBeregn.Location = new System.Drawing.Point(12, 478);
            this.btnBeregn.Name = "btnBeregn";
            this.btnBeregn.Size = new System.Drawing.Size(279, 163);
            this.btnBeregn.TabIndex = 42;
            this.btnBeregn.Text = "Beregn";
            this.btnBeregn.UseVisualStyleBackColor = false;
            this.btnBeregn.Click += new System.EventHandler(this.btnBeregn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.Location = new System.Drawing.Point(12, 336);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(180, 29);
            this.label11.TabIndex = 44;
            this.label11.Text = "Ansvarlig navn";
            // 
            // txtAnsvarlig
            // 
            this.txtAnsvarlig.Location = new System.Drawing.Point(12, 389);
            this.txtAnsvarlig.Multiline = true;
            this.txtAnsvarlig.Name = "txtAnsvarlig";
            this.txtAnsvarlig.Size = new System.Drawing.Size(371, 41);
            this.txtAnsvarlig.TabIndex = 43;
            // 
            // numP1
            // 
            this.numP1.Location = new System.Drawing.Point(26, 156);
            this.numP1.Name = "numP1";
            this.numP1.Size = new System.Drawing.Size(120, 31);
            this.numP1.TabIndex = 45;
            // 
            // numV1
            // 
            this.numV1.Location = new System.Drawing.Point(244, 156);
            this.numV1.Name = "numV1";
            this.numV1.Size = new System.Drawing.Size(120, 31);
            this.numV1.TabIndex = 46;
            // 
            // numP2
            // 
            this.numP2.Location = new System.Drawing.Point(26, 258);
            this.numP2.Name = "numP2";
            this.numP2.Size = new System.Drawing.Size(120, 31);
            this.numP2.TabIndex = 47;
            // 
            // numV2
            // 
            this.numV2.Location = new System.Drawing.Point(247, 258);
            this.numV2.Name = "numV2";
            this.numV2.Size = new System.Drawing.Size(120, 31);
            this.numV2.TabIndex = 48;
            // 
            // btnMål1
            // 
            this.btnMål1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMål1.Font = new System.Drawing.Font("Arial", 9.047121F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMål1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnMål1.Location = new System.Drawing.Point(428, 150);
            this.btnMål1.Name = "btnMål1";
            this.btnMål1.Size = new System.Drawing.Size(126, 44);
            this.btnMål1.TabIndex = 49;
            this.btnMål1.Text = "Mål";
            this.btnMål1.UseVisualStyleBackColor = false;
            this.btnMål1.Click += new System.EventHandler(this.btnMål1_Click);
            // 
            // btnMål2
            // 
            this.btnMål2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMål2.Font = new System.Drawing.Font("Arial", 9.047121F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMål2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnMål2.Location = new System.Drawing.Point(428, 252);
            this.btnMål2.Name = "btnMål2";
            this.btnMål2.Size = new System.Drawing.Size(126, 44);
            this.btnMål2.TabIndex = 50;
            this.btnMål2.Text = "Mål";
            this.btnMål2.UseVisualStyleBackColor = false;
            this.btnMål2.Click += new System.EventHandler(this.btnMål2_Click);
            // 
            // Kalibrer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(755, 653);
            this.Controls.Add(this.btnMål2);
            this.Controls.Add(this.btnMål1);
            this.Controls.Add(this.numV2);
            this.Controls.Add(this.numP2);
            this.Controls.Add(this.numV1);
            this.Controls.Add(this.numP1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtAnsvarlig);
            this.Controls.Add(this.btnBeregn);
            this.Controls.Add(this.txtResultat);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnOK);
            this.Name = "Kalibrer";
            this.Text = "Kalibrer";
            ((System.ComponentModel.ISupportInitialize)(this.numP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numV1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numV2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtResultat;
        private System.Windows.Forms.Button btnBeregn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtAnsvarlig;
        private System.Windows.Forms.NumericUpDown numP1;
        private System.Windows.Forms.NumericUpDown numV1;
        private System.Windows.Forms.NumericUpDown numP2;
        private System.Windows.Forms.NumericUpDown numV2;
        private System.Windows.Forms.Button btnMål1;
        private System.Windows.Forms.Button btnMål2;
    }
}