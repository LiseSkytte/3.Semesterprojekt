﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logik;
using DTO;

namespace GUI
{
    public partial class Kalibrer : Form
    {
        Beregninger beregninger;
        private double stigning;
        private double p1;
        private double p2;
        private double v1;
        private double v2;
        
        

        public Kalibrer(Beregninger beregn)
        {
            InitializeComponent();
            numP1.Maximum = 20000;
            numP2.Maximum = 20000;
            numV1.Maximum = 20000;
            numV2.Maximum = 20000;
            numV1.Minimum = -20000;
            numV2.Minimum = -20000;
            numV1.DecimalPlaces = 3;
            numV2.DecimalPlaces = 3;
            beregninger = beregn;
            txtResultat.Text = beregninger.getslopestring();
            
        }


        private void btnBeregn_Click(object sender, EventArgs e)
        {
            try
            {
                p1 = Convert.ToDouble(numP1.Value);
                p2 = Convert.ToDouble(numP2.Value);
                v1 = Convert.ToDouble(numV1.Value);
                v2 = Convert.ToDouble(numV2.Value);
                stigning = beregninger.beregnKalibrering(p1, p2, v1, v2);
                txtResultat.Text = ("Beregnede stigning mmHg/V: " + Math.Round(stigning, 2) + "\r\nFor at anvende tryk 'OK'");
                btnOK.Enabled = true;
                if (txtAnsvarlig.Text == "")
                {
                    txtResultat.Text = ("Beregnede stigning mmHg/V: " + Math.Round(stigning, 1) + "\r\nIndtast navn og tryk 'BEREGN' for at kunne anvende");
                    btnOK.Enabled = false;
                }
            }
            catch (Exception)
            {
                txtResultat.Text = ("Indtastede værdier er ugyldige, prøv igen");
            }
        }


        private void btnOK_Click(object sender, EventArgs e)
        {
            if (beregninger.gemkalibrering(stigning, txtAnsvarlig.Text) == true)
            {
                txtResultat.Text = ("Kalibrering er gemt. Vindue kan lukkes");
            }
            else
            {
                txtResultat.Text = ("FEJL opstod. Kalibrering ikke gemt");
            }
        }


        private void btnMål1_Click(object sender, EventArgs e)
        {
            getVoltage1();
        }

        private void getVoltage1()
        {
            numV1.Value = Convert.ToDecimal(beregninger.beregnSpænding());
        }

        private void btnMål2_Click(object sender, EventArgs e)
        {
            getVoltage2();
        }

        private void getVoltage2()
        {
            numV2.Value = Convert.ToDecimal(beregninger.beregnSpænding());
        }

    }
}
        

