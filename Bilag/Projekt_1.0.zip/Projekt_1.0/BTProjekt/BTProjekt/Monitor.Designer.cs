﻿namespace GUI
{
    partial class Monitor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnNulpktJuster = new System.Windows.Forms.Button();
            this.labelSYS = new System.Windows.Forms.Label();
            this.labelDIA = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGem = new System.Windows.Forms.Button();
            this.labelPuls = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxNulpkt = new System.Windows.Forms.TextBox();
            this.BtnRec = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gridButtonon = new System.Windows.Forms.RadioButton();
            this.gridButtonoff = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdoFilterOn = new System.Windows.Forms.RadioButton();
            this.rdoFilterOff = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labeltimer = new System.Windows.Forms.Label();
            this.textBoxlængde = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.labelXakse = new System.Windows.Forms.Label();
            this.labelYakse = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chart1.BackImageTransparentColor = System.Drawing.Color.Black;
            this.chart1.BackSecondaryColor = System.Drawing.Color.Black;
            chartArea6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea6.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart1.Legends.Add(legend6);
            this.chart1.Location = new System.Drawing.Point(22, 23);
            this.chart1.Name = "chart1";
            series6.BackImageTransparentColor = System.Drawing.Color.Black;
            series6.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Color = System.Drawing.Color.Red;
            series6.IsVisibleInLegend = false;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chart1.Series.Add(series6);
            this.chart1.Size = new System.Drawing.Size(1558, 579);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // btnNulpktJuster
            // 
            this.btnNulpktJuster.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnNulpktJuster.Font = new System.Drawing.Font("Arial", 10.17801F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNulpktJuster.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnNulpktJuster.Location = new System.Drawing.Point(22, 650);
            this.btnNulpktJuster.Name = "btnNulpktJuster";
            this.btnNulpktJuster.Size = new System.Drawing.Size(279, 91);
            this.btnNulpktJuster.TabIndex = 1;
            this.btnNulpktJuster.Text = "Nulpunktsjuster";
            this.btnNulpktJuster.UseVisualStyleBackColor = false;
            this.btnNulpktJuster.Click += new System.EventHandler(this.btnNulpktJuster_Click);
            // 
            // labelSYS
            // 
            this.labelSYS.AutoSize = true;
            this.labelSYS.Font = new System.Drawing.Font("Arial Black", 36.18848F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSYS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelSYS.Location = new System.Drawing.Point(1647, 23);
            this.labelSYS.Name = "labelSYS";
            this.labelSYS.Size = new System.Drawing.Size(249, 136);
            this.labelSYS.TabIndex = 4;
            this.labelSYS.Text = "132";
            // 
            // labelDIA
            // 
            this.labelDIA.AutoSize = true;
            this.labelDIA.Font = new System.Drawing.Font("Arial", 26.01047F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDIA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelDIA.Location = new System.Drawing.Point(1664, 174);
            this.labelDIA.Name = "labelDIA";
            this.labelDIA.Size = new System.Drawing.Size(128, 77);
            this.labelDIA.TabIndex = 5;
            this.labelDIA.Text = "/91";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(1673, 253);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 26);
            this.label1.TabIndex = 6;
            this.label1.Text = "Diastolisk";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label2.Location = new System.Drawing.Point(1673, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 26);
            this.label2.TabIndex = 7;
            this.label2.Text = "Systolisk";
            // 
            // btnGem
            // 
            this.btnGem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnGem.Font = new System.Drawing.Font("Arial", 21.86387F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGem.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnGem.Location = new System.Drawing.Point(1617, 681);
            this.btnGem.Name = "btnGem";
            this.btnGem.Size = new System.Drawing.Size(279, 163);
            this.btnGem.TabIndex = 4;
            this.btnGem.Text = "Gem";
            this.btnGem.UseVisualStyleBackColor = false;
            this.btnGem.Click += new System.EventHandler(this.btnGem_Click);
            // 
            // labelPuls
            // 
            this.labelPuls.AutoSize = true;
            this.labelPuls.Font = new System.Drawing.Font("Arial", 33.17278F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPuls.ForeColor = System.Drawing.Color.LawnGreen;
            this.labelPuls.Location = new System.Drawing.Point(1664, 351);
            this.labelPuls.Name = "labelPuls";
            this.labelPuls.Size = new System.Drawing.Size(140, 100);
            this.labelPuls.TabIndex = 11;
            this.labelPuls.Text = "69";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Location = new System.Drawing.Point(1673, 436);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 26);
            this.label4.TabIndex = 12;
            this.label4.Text = "Puls";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.09424F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(1180, 714);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 55);
            this.label5.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.06283F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Location = new System.Drawing.Point(1520, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 38);
            this.label3.TabIndex = 14;
            this.label3.Text = "Filter";
            // 
            // txtBoxNulpkt
            // 
            this.txtBoxNulpkt.Location = new System.Drawing.Point(22, 759);
            this.txtBoxNulpkt.Multiline = true;
            this.txtBoxNulpkt.Name = "txtBoxNulpkt";
            this.txtBoxNulpkt.Size = new System.Drawing.Size(279, 91);
            this.txtBoxNulpkt.TabIndex = 17;
            // 
            // BtnRec
            // 
            this.BtnRec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnRec.Font = new System.Drawing.Font("Arial", 21.86387F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRec.ForeColor = System.Drawing.Color.DarkRed;
            this.BtnRec.Location = new System.Drawing.Point(1306, 681);
            this.BtnRec.Name = "BtnRec";
            this.BtnRec.Size = new System.Drawing.Size(279, 163);
            this.BtnRec.TabIndex = 3;
            this.BtnRec.Text = "Rec";
            this.BtnRec.UseVisualStyleBackColor = false;
            this.BtnRec.Click += new System.EventHandler(this.BtnRec_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(339, 737);
            this.trackBar1.Maximum = 120;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(924, 90);
            this.trackBar1.TabIndex = 20;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.Location = new System.Drawing.Point(674, 694);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(219, 29);
            this.label8.TabIndex = 22;
            this.label8.Text = "Optagelse længde";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.06283F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.Location = new System.Drawing.Point(1520, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 38);
            this.label7.TabIndex = 26;
            this.label7.Text = "Grid";
            // 
            // gridButtonon
            // 
            this.gridButtonon.AutoSize = true;
            this.gridButtonon.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.gridButtonon.Location = new System.Drawing.Point(23, 13);
            this.gridButtonon.Name = "gridButtonon";
            this.gridButtonon.Size = new System.Drawing.Size(66, 30);
            this.gridButtonon.TabIndex = 25;
            this.gridButtonon.TabStop = true;
            this.gridButtonon.Text = "On";
            this.gridButtonon.UseVisualStyleBackColor = true;
            this.gridButtonon.CheckedChanged += new System.EventHandler(this.gridButtonon_CheckedChanged);
            // 
            // gridButtonoff
            // 
            this.gridButtonoff.AutoSize = true;
            this.gridButtonoff.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.gridButtonoff.Location = new System.Drawing.Point(23, 55);
            this.gridButtonoff.Name = "gridButtonoff";
            this.gridButtonoff.Size = new System.Drawing.Size(66, 30);
            this.gridButtonoff.TabIndex = 24;
            this.gridButtonoff.TabStop = true;
            this.gridButtonoff.Text = "Off";
            this.gridButtonoff.UseVisualStyleBackColor = true;
            this.gridButtonoff.CheckedChanged += new System.EventHandler(this.gridButtonoff_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdoFilterOn);
            this.panel1.Controls.Add(this.rdoFilterOff);
            this.panel1.Location = new System.Drawing.Point(1504, 191);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(105, 100);
            this.panel1.TabIndex = 29;
            // 
            // rdoFilterOn
            // 
            this.rdoFilterOn.AutoSize = true;
            this.rdoFilterOn.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.rdoFilterOn.Location = new System.Drawing.Point(16, 18);
            this.rdoFilterOn.Name = "rdoFilterOn";
            this.rdoFilterOn.Size = new System.Drawing.Size(66, 30);
            this.rdoFilterOn.TabIndex = 10;
            this.rdoFilterOn.TabStop = true;
            this.rdoFilterOn.Text = "On";
            this.rdoFilterOn.UseVisualStyleBackColor = true;
            this.rdoFilterOn.CheckedChanged += new System.EventHandler(this.rdoFilterOn_CheckedChanged);
            // 
            // rdoFilterOff
            // 
            this.rdoFilterOff.AutoSize = true;
            this.rdoFilterOff.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.rdoFilterOff.Location = new System.Drawing.Point(16, 60);
            this.rdoFilterOff.Name = "rdoFilterOff";
            this.rdoFilterOff.Size = new System.Drawing.Size(66, 30);
            this.rdoFilterOff.TabIndex = 9;
            this.rdoFilterOff.TabStop = true;
            this.rdoFilterOff.Text = "Off";
            this.rdoFilterOff.UseVisualStyleBackColor = true;
            this.rdoFilterOff.CheckedChanged += new System.EventHandler(this.rdoFilterOff_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.gridButtonon);
            this.panel2.Controls.Add(this.gridButtonoff);
            this.panel2.Location = new System.Drawing.Point(1504, 351);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(114, 100);
            this.panel2.TabIndex = 30;
            // 
            // labeltimer
            // 
            this.labeltimer.AutoSize = true;
            this.labeltimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.93194F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltimer.ForeColor = System.Drawing.Color.DarkRed;
            this.labeltimer.Location = new System.Drawing.Point(1514, 690);
            this.labeltimer.Name = "labeltimer";
            this.labeltimer.Size = new System.Drawing.Size(45, 36);
            this.labeltimer.TabIndex = 31;
            this.labeltimer.Text = "---";
            // 
            // textBoxlængde
            // 
            this.textBoxlængde.Location = new System.Drawing.Point(741, 796);
            this.textBoxlængde.Name = "textBoxlængde";
            this.textBoxlængde.Size = new System.Drawing.Size(100, 31);
            this.textBoxlængde.TabIndex = 2;
            this.textBoxlængde.TextChanged += new System.EventHandler(this.textBoxlængde_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.047121F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.Location = new System.Drawing.Point(847, 798);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 29);
            this.label6.TabIndex = 33;
            this.label6.Text = "sek";
            // 
            // labelXakse
            // 
            this.labelXakse.AutoSize = true;
            this.labelXakse.Location = new System.Drawing.Point(1431, 576);
            this.labelXakse.Name = "labelXakse";
            this.labelXakse.Size = new System.Drawing.Size(70, 26);
            this.labelXakse.TabIndex = 34;
            this.labelXakse.Text = "Tid / s";
            // 
            // labelYakse
            // 
            this.labelYakse.AutoSize = true;
            this.labelYakse.Location = new System.Drawing.Point(91, 9);
            this.labelYakse.Name = "labelYakse";
            this.labelYakse.Size = new System.Drawing.Size(137, 26);
            this.labelYakse.TabIndex = 35;
            this.labelYakse.Text = "Tryk / mmHg";
            // 
            // Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1908, 868);
            this.Controls.Add(this.labelYakse);
            this.Controls.Add(this.labelXakse);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxlængde);
            this.Controls.Add(this.labeltimer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.BtnRec);
            this.Controls.Add(this.txtBoxNulpkt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelPuls);
            this.Controls.Add(this.btnGem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelDIA);
            this.Controls.Add(this.labelSYS);
            this.Controls.Add(this.btnNulpktJuster);
            this.Controls.Add(this.chart1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Monitor";
            this.Text = "Monitor";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnNulpktJuster;
        private System.Windows.Forms.Label labelSYS;
        private System.Windows.Forms.Label labelDIA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGem;
        private System.Windows.Forms.Label labelPuls;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxNulpkt;
        private System.Windows.Forms.Button BtnRec;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton gridButtonon;
        private System.Windows.Forms.RadioButton gridButtonoff;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdoFilterOn;
        private System.Windows.Forms.RadioButton rdoFilterOff;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labeltimer;
        private System.Windows.Forms.TextBox textBoxlængde;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelXakse;
        private System.Windows.Forms.Label labelYakse;
    }
}

