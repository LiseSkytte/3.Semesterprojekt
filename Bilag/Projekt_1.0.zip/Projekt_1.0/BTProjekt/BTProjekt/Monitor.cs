﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Logik;
using DTO;
using BTProjekt;


namespace GUI
{
    public partial class Monitor : Form, ISubscriber
    {
        // Metoders Attributter
        Beregninger beregninger;
        Kalibrer kalibrer;

        // Filter Radio button
        private bool filteron;

        // Update
        private int rotation;
        private int counter = 0;
        private int counter2 = 0;
        private int maaletid = -100;
        List<DTO_BT> dtolist;
        
        // btnNulpunktsjuter
        private DateTime time;

        public Monitor()
        {
            InitializeComponent();
            filteron = new bool();
            beregninger = new Beregninger();
            kalibrer = new Kalibrer(beregninger);
            kalibrer.Show();
            kalibrer.TopMost = true;
            beregninger.AttachSubscriber(this);
            startreader("Dev1/ai0", -5, 5, 1000, 50);


            //Textboxes
            txtBoxNulpkt.Text = (beregninger.getnulpunktsstring());
            textBoxlængde.Text = "60";
            trackBar1.Value = 60;

            //GRAPH VISUALS

            chart1.ChartAreas[0].AxisX.Maximum = 4;
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.Series[0].BorderWidth = 2;
            btnGem.Enabled = false;
            gridButtonoff.Checked = false;
            gridButtonon.Checked = true;
            rdoFilterOff.Checked = false;
            rdoFilterOn.Checked = true;
        }
        public void startreader(string inputport, double min, double max, double samplefrekvens, int antalsamples)
        {
            beregninger.startreader(inputport, min, max, samplefrekvens, antalsamples);
        }            
        private void rdoFilterOff_CheckedChanged(object sender, EventArgs e)
        {
            filteron = false;
        }
        private void rdoFilterOn_CheckedChanged(object sender, EventArgs e)
        {
            filteron = true;
        }
        public void Update(List<double> liste)
        {
            dtolist = beregninger.beregnblodtryk(liste, filteron);
            counter++;
            counter2++;

            if (chart1.Series[0].Points.Count()<400)
            {
                
                if (counter2 == 1)
                {
                    chart1.ChartAreas[0].AxisY.Minimum = Math.Round(liste.Min()*beregninger.getslopedouble()-beregninger.getnulpunktdouble(), 0) - 40;
                    chart1.ChartAreas[0].AxisY.Maximum = Math.Round(liste.Max()*beregninger.getslopedouble() - beregninger.getnulpunktdouble(), 0) + 40;                 
                }

                chart1.Series[0].Points.AddXY(dtolist[0].gettime(), dtolist[0].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[1].gettime(), dtolist[1].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[2].gettime(), dtolist[2].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[3].gettime(), dtolist[3].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[4].gettime(), dtolist[4].getvoltage());

                writetimer();

            }
            else if(chart1.Series[0].Points.Count()>=400)
            {
                rotation++;
                chart1.Series[0].Points.Clear();
                chart1.ChartAreas[0].AxisX.Minimum = 4 * rotation;
                chart1.ChartAreas[0].AxisX.Maximum = 4 * (rotation+1);
                chart1.Series[0].Points.AddXY(dtolist[0].gettime(), dtolist[0].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[1].gettime(), dtolist[1].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[2].gettime(), dtolist[2].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[3].gettime(), dtolist[3].getvoltage());
                chart1.Series[0].Points.AddXY(dtolist[4].gettime(), dtolist[4].getvoltage());
                chart1.ChartAreas[0].AxisY.Minimum = Math.Round(beregninger.getlatest1000().Min() * beregninger.getslopedouble() - beregninger.getnulpunktdouble(), 0) - 10;
                chart1.ChartAreas[0].AxisY.Maximum = Math.Round(beregninger.getlatest1000().Max() * beregninger.getslopedouble() - beregninger.getnulpunktdouble(), 0) + 10;

            }
            try
            {
                if (counter > 20)
                {
                    counter = 0;
                    labelSYS.Text = Convert.ToString(Math.Round(beregninger.BeregnSYS(),0));
                    labelDIA.Text = Convert.ToString(Math.Round(beregninger.BeregnDIA(), 0));
                    labelPuls.Text = Convert.ToString(Math.Round(beregninger.Beregnpuls(), 0));

                }
                
            }

            catch (Exception)
            {
            }

            maaletid = maaletid - 50;
            if (maaletid == -50 &&BtnRec.Text=="Stop")
            {
                record();
            }

        

        }
        private void btnNulpktJuster_Click(object sender, EventArgs e)
        {
            time = DateTime.Now;
            try
            {
                if (beregninger.setNulpunktstryk(beregninger.beregnSpænding()/1000*beregninger.getslopedouble()) == true)
                {
                    txtBoxNulpkt.Text = beregninger.getnulpunktsstring();
                }
                else
                {
                    txtBoxNulpkt.Text = ("Ikke nulpuntsjusteret");
                }
            }
            catch (Exception)
            {
                txtBoxNulpkt.Text = ("Ikke nulpuntsjusteret");
            }
        }
        private void btnGem_Click(object sender, EventArgs e)
        {
            åbnGem();
        } 
        private void åbnGem()
        {
            Gem gem = new Gem(beregninger, beregninger.getslopedouble(), beregninger.getnulpunktdouble(), beregninger.getStart(), beregninger.getSlut(), beregninger.getsamplelist());
            gem.visGemGraf();
            gem.Show();
        }              
        private void BtnRec_Click(object sender, EventArgs e)
        {
            record();    
        }
        private void record()
        {
            if (BtnRec.Text == "Stop")
            {
                BtnRec.Text = "Rec";
                beregninger.record(true);
                btnGem.Enabled = true;
                btnNulpktJuster.Enabled = true;
                trackBar1.Enabled = true;
                textBoxlængde.Enabled = true;
            }
            else if (BtnRec.Text == "Rec")
            {
                try
                {
                    maaletid = Convert.ToInt16(textBoxlængde.Text) * 1000;
                    BtnRec.Text = "Stop";
                    beregninger.record(false);
                    btnGem.Enabled = false;
                    btnNulpktJuster.Enabled = false;
                    trackBar1.Enabled = false;
                    textBoxlængde.Enabled = false;

                }
                catch (Exception)
                {
                    textBoxlængde.Text = ("hele tal tak");
                }


            }
        }        
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBoxlængde.Text = Convert.ToString(trackBar1.Value);                      
        }
        private void gridButtonon_CheckedChanged(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;
            chart1.ChartAreas[0].AxisX.LabelStyle.Enabled = true;
            chart1.ChartAreas[0].AxisY.LabelStyle.Enabled = true;
            chart1.ChartAreas[0].AxisY.LineWidth = 1;
            chart1.ChartAreas[0].AxisX.LineWidth = 1;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisY.Interval = 10;
            labelXakse.Visible = true;
            labelYakse.Visible = true;
        }
        private void gridButtonoff_CheckedChanged(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart1.ChartAreas[0].AxisX.LabelStyle.Enabled = false;
            chart1.ChartAreas[0].AxisY.LabelStyle.Enabled = false;
            chart1.ChartAreas[0].AxisY.LineWidth = 0;
            chart1.ChartAreas[0].AxisX.LineWidth = 0;
            chart1.ChartAreas[0].AxisX.Interval = 0;
            chart1.ChartAreas[0].AxisY.Interval = 0;
            labelXakse.Visible = false;
            labelYakse.Visible = false;
        }
        private void writetimer()
        {
            if (BtnRec.Text == "Stop")
            {
                labeltimer.Text = Convert.ToString(Math.Round(Convert.ToDouble(maaletid) / 1000, 0));
            }
            else if (BtnRec.Text == "Rec")
            {
                labeltimer.Text = "--";

            }
        }
        private void textBoxlængde_TextChanged(object sender, EventArgs e)
        {
            try
            {
                trackBar1.Value = Convert.ToInt16(textBoxlængde.Text);
            }
            catch (Exception)
            {
                trackBar1.Value = 120;
            }
        }

    }
}
