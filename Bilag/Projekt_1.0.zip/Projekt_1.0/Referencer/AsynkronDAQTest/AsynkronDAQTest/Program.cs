﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Data;

namespace AsynkronDAQTest
{
    class Program
    {
        private static ST3DAQ mindaq;
        private List<double> minliste = new List<double>();
        
        static void Main(string[] args)
        {
            mindaq = new ST3DAQ();

            mindaq.startReadData("Dev1/ai0", -2.1, 2.1, 10000, 1000);

            //while (mindaq.IsRunning() && Console.KeyAvailable == false)
            //{
            //    foreach (DataRow row in mindaq.dataTable.Rows)
            //    {
            //        for (int x = 0; x < mindaq.dataTable.Columns.Count; x++)
            //        {
            //            Console.Write(row[x].ToString() + " ");
            //        }
            //        Console.WriteLine();
            //    }

            //}
            do
            {
                for (int i = 0; i < mindaq.getnoglesamples().Count; i++)
                {
                    Console.WriteLine(mindaq.getnoglesamples()[i]);
                }           
            } while (true); 
            
            mindaq.stopReadData();
        }
    }
}
