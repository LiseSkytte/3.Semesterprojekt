﻿using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using NationalInstruments.DAQmx;
using NationalInstruments;

namespace AsynkronDAQTest
{
    public class ST3DAQ
    {
        private AnalogMultiChannelReader analogInReader;
        private Task myTask;
        private Task runningTask;
        private AsyncCallback analogCallback;

        private AnalogWaveform<double>[] data;
        private DataColumn[] dataColumn = null;
        public DataTable dataTable = null;
        private int samplesPrChannel;

        // EGEN KODE
        public List<double> noglesamples = new List<double>();
        int sidsttilføjet = 0;

        public ST3DAQ()
        {   
            dataTable = new DataTable();
        }

        public bool IsRunning()
        {
            if (runningTask != null)
            {
                return true;
            }
            else { return false; }
        }

        public void startReadData(string readPort, double minValue, double maxValue, double rate, int samples)
        {
            if (runningTask == null)
            {
                try
                {
                    samplesPrChannel = samples;

                    // Create a new task
                    myTask = new Task();

                    // Create a virtual channel
                    myTask.AIChannels.CreateVoltageChannel(readPort, "",
                        (AITerminalConfiguration)(-1), minValue,
                        maxValue, AIVoltageUnits.Volts);


                    // Configure the timing parameters
                    myTask.Timing.ConfigureSampleClock("", rate,
                        SampleClockActiveEdge.Rising, SampleQuantityMode.ContinuousSamples, 1000);

                    // Verify the Task
                    myTask.Control(TaskAction.Verify);

                    // Prepare the table for Data
                    InitializeDataTable(myTask.AIChannels, ref dataTable);

                    runningTask = myTask;
                    analogInReader = new AnalogMultiChannelReader(myTask.Stream);
                    analogCallback = new AsyncCallback(AnalogInCallback);

                    // Use SynchronizeCallbacks to specify that the object 
                    // marshals callbacks across threads appropriately.
                    analogInReader.SynchronizeCallbacks = true;
                    analogInReader.BeginReadWaveform(samples, analogCallback, myTask);
                }
                catch (DaqException exception)
                {
                    runningTask = null;
                    myTask.Dispose(); 
                }
            }
        }

        private void AnalogInCallback(IAsyncResult ar)
        {
            try
            {
                if (runningTask != null && runningTask == ar.AsyncState)
                {
                    // Read the available data from the channels
                    data = analogInReader.EndReadWaveform(ar);

                    // Plot your data here
                    dataToDataTable(data, ref dataTable);

                    analogInReader.BeginMemoryOptimizedReadWaveform(samplesPrChannel,
                        analogCallback, myTask, data);
                }
            }
            catch (DaqException exception)
            {
                // Display Errors
                runningTask = null;
                myTask.Dispose();
            }
        }

        public void stopReadData()
        {
            if (runningTask != null)
            {
                // Dispose of the task
                runningTask = null;
                myTask.Dispose();
            }
        }

        private void dataToDataTable(AnalogWaveform<double>[] sourceArray, ref DataTable dataTable)
        {

            int currentLineIndex = 0;
            foreach (AnalogWaveform<double> waveform in sourceArray)
            {
                //for (int sample = 0; sample < waveform.Samples.Count; ++sample)
                //{
                //    if (sample == 10)
                //        break;

                //    dataTable.Rows[sample][currentLineIndex] = waveform.Samples[sample].Value;
                //}

                for (int i = sidsttilføjet; i < waveform.Samples.Count; i++)
                {
                    if (i==10)
                    {
                        break;
                    }
                    noglesamples.Add(waveform.Samples[i].Value);
                }
                sidsttilføjet = sourceArray.Length;
                currentLineIndex++;
            }
        }

        public List<double> getnoglesamples()
        {
            return noglesamples;
        }

        public void InitializeDataTable(AIChannelCollection channelCollection, ref DataTable data)
        {
            int numOfChannels = channelCollection.Count;
            data.Rows.Clear();
            data.Columns.Clear();
            dataColumn = new DataColumn[numOfChannels];
            int numOfRows = 10;

            for (int currentChannelIndex = 0; currentChannelIndex < numOfChannels; currentChannelIndex++)
            {
                dataColumn[currentChannelIndex] = new DataColumn();
                dataColumn[currentChannelIndex].DataType = typeof(double);
                dataColumn[currentChannelIndex].ColumnName = channelCollection[currentChannelIndex].PhysicalName;
            }

            data.Columns.AddRange(dataColumn);

            for (int currentDataIndex = 0; currentDataIndex < numOfRows; currentDataIndex++)
            {
                object[] rowArr = new object[numOfChannels];
                data.Rows.Add(rowArr);
            }
        }
    }
}